/*
 * TimesheetController.java
 *
 * Created on 23 August 2011, 23:14
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 *
 * @author Christopher
 */
package dolphinbackuptape;
import java.sql.*;
import java.util.*;
public class BackupTapeController {
    
    static Connection conn = null;
    
    /** Creates a new instance of TimesheetController */
    public BackupTapeController() {
    }
    public void establishConnection(String username, String password)
    {
         try
        {  
            Class.forName("net.sourceforge.jtds.jdbc.Driver"); 
            String url = "jdbc:jtds:sqlserver://localhost:1433/BackupTape;instance=SQLEXPRESS;namedPipe=true"; 
            conn = DriverManager.getConnection(url, username, password);
        }
         catch (Exception e)
        { 
            System.err.println("Exception: "); 
            System.err.println(e.getMessage()); 
        }
    }
         public void addTapeSet(String rig, String type, int month, int year, String location, String code)
         {
             try
             {
                String query = "INSERT INTO TapeSet (Rig, Type, Month, Year, Location, Code) " +
                        "VALUES (" + "?, ?, ?, ?, ?, ?)";
                PreparedStatement ps = conn.prepareStatement(query);
                ps.setString(1, rig);
                ps.setString(2, type);
                ps.setInt(3, month);
                ps.setInt(4, year);
                ps.setString(5, location);
                ps.setString(6, code);
                ps.executeUpdate();
                ps.close();
             }
             catch (SQLException e)
             {
                System.err.println("Exception: "); 
                System.err.println(e.getMessage());    
             }
         }
         
         public void removeTapeSet(String tapeCode)
         {
             try
             {
                String query = "DELETE FROM TapeSet WHERE Code = " +
                        "?";
                PreparedStatement ps = conn.prepareStatement(query);
                ps.setString(1, tapeCode);
                ps.executeUpdate();
                ps.close();
             }
             catch (SQLException e)
             {
                System.err.println("Exception: "); 
                System.err.println(e.getMessage());    
             }
         } 
         public static Connection getConnection()
         {
             return conn;         
             }

             

}
