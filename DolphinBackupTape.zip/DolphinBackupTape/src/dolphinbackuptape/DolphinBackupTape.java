/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dolphinbackuptape;

/**
 *
 * @author Christopher
 */
public class DolphinBackupTape {
    static BackupTapeController btc = null;
    static StartFrame homeScreen = null;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       btc = new BackupTapeController();
       btc.establishConnection("dolphin","dolphin99");
       homeScreen = new StartFrame();
       homeScreen.setVisible(true);
       // btc.addTapeSet("Belford", "Month", 9, 2012, "ABZ", "BELM92012");
       // btc.removeTapeSet("BELM92012");
    }
    public static BackupTapeController getBackupTapeController () {
        return btc;
    }
    public static StartFrame getHomeScreen () {
        return homeScreen;
    }
}
